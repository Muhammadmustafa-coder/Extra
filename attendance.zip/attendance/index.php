<?php
// Fallback front controller for hosts that don't allow setting DocumentRoot
// to the `public/` directory. This changes the working directory to `public/`
// and delegates handling to the real front controller.

chdir(__DIR__ . '/public');
require __DIR__ . '/public/index.php';
