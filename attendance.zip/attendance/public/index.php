<?php
require __DIR__ . '/../vendor/autoload.php';

date_default_timezone_set('Asia/Karachi');
use DI\Container;
use Slim\Factory\AppFactory;
use App\Controllers\AuthController;
use App\Controllers\MiqaatController;
use App\Controllers\AttendanceController;

// Configure session cookie path according to deployment base path. Set APP_BASE_PATH
// environment variable on the server (e.g. '/attendance').
$basePath = getenv('APP_BASE_PATH') ?: '/attendance';
$secureCookie = (getenv('APP_SECURE') === '1');
session_set_cookie_params(['path' => $basePath, 'httponly' => true, 'secure' => $secureCookie]);
session_start();

$container = new Container();
$pdoFactory = require __DIR__ . '/../config/database.php';
// Register the PDO factory itself (lazy) so the app doesn't attempt a DB
// connection during bootstrap. The container will invoke the factory when
// the PDO service is actually requested.
$container->set(PDO::class, $pdoFactory);

// Register controllers explicitly so they can be autowired with PDO
$container->set(AuthController::class, function ($c) use ($pdoFactory) {
	// Pass the PDO factory closure so the controller can create a connection only when needed.
	return new AuthController($pdoFactory);
});
$container->set(MiqaatController::class, function ($c) {
	return new MiqaatController($c->get(PDO::class));
});
$container->set(AttendanceController::class, function ($c) {
	return new AttendanceController($c->get(PDO::class));
});

AppFactory::setContainer($container);
$app = AppFactory::create();

// If the app is deployed in a subfolder, set Slim base path from environment
// variable `APP_BASE_PATH` (defaults to '/attendance').
$app->setBasePath($basePath);

require __DIR__ . '/../app/helpers.php';
require __DIR__ . '/../app/middleware.php';
require __DIR__ . '/../app/routes.php';

$app->run();