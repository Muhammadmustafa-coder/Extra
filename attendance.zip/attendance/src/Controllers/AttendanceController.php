<?php
namespace App\Controllers;

use PDO;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;

class AttendanceController
{
  private PDO $db;

  public function __construct(PDO $db)
  {
    $this->db = $db;
  }

  public function mark(Request $req, Response $res, $args): Response
  {
    $stmt = $this->db->prepare("SELECT id, title FROM miqaats WHERE qr_token = ?");
    $stmt->execute([$args['token']]);
    $miqaat = $stmt->fetch();

    if (!$miqaat) {
      return \view($res, 'attendance/result', ['message' => 'Invalid or expired QR code', 'status' => 'error']);
    }

    // Manual Auth Check (since we removed middleware to provide custom login message)
    if (!isset($_SESSION['user_id'])) {
      $uri = $req->getUri()->getPath();
      $message = "Please login with your credentials to mark your attendance for " . $miqaat['title'];
      return $res->withHeader('Location', \url('/login?redirect=' . urlencode($uri) . '&notice=' . urlencode($message)))
        ->withStatus(302);
    }

    // Prevent Admin from marking attendance
    if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
      return \view($res, 'attendance/result', [
        'message' => 'You are logged in as an Admin. Please <a href="' . \url('/logout') . '" style="text-decoration:underline;color:inherit;">logout</a> first and then sign in with your member account credentials to mark attendance.',
        'status' => 'error'
      ]);
    }

    // Check for existing attendance
    $stmt = $this->db->prepare("SELECT id FROM attendance WHERE miqaat_id = ? AND user_id = ?");
    $stmt->execute([$miqaat['id'], $_SESSION['user_id']]);
    if ($stmt->fetch()) {
      return \view($res, 'attendance/result', [
        'message' => 'Your attendance has already been marked for ' . $miqaat['title'],
        'status' => 'warning'
      ]);
    }

    $server = $req->getServerParams();
    $ip = $server['REMOTE_ADDR'] ?? '0.0.0.0';
    $ua = $server['HTTP_USER_AGENT'] ?? '';

    $insertStats = $this->db->prepare(
      "INSERT INTO attendance (miqaat_id, user_id, ip_address, user_agent, created_at) VALUES (?, ?, ?, ?, ?)"
    );

    try {
      $insertStats->execute([
        $miqaat['id'],
        $_SESSION['user_id'],
        $ip,
        $ua,
        date('Y-m-d H:i:s') // Explicitly insert current PST time
      ]);
      return \view($res, 'attendance/result', [
        'message' => 'Thank You, your attendance has been successfully marked for ' . $miqaat['title'],
        'status' => 'success'
      ]);
    } catch (\PDOException $e) {
      return \view($res, 'attendance/result', ['message' => 'Database error', 'status' => 'error']);
    }
  }
}
