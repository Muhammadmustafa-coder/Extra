<?php
namespace App\Controllers;

use PDO;
use Endroid\QrCode\Builder\Builder;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;

class MiqaatController
{
  private PDO $db;

  public function __construct(PDO $db)
  {
    $this->db = $db;
  }

  public function index(Request $request, Response $response): Response
  {
    // Fetch miqaats with creator username
    $sql = "SELECT m.*, u.username as creator_name 
            FROM miqaats m 
            LEFT JOIN users u ON m.created_by = u.id 
            ORDER BY m.miqaat_date DESC";
    $miqaats = $this->db->query($sql)->fetchAll();
    return \view($response, 'admin/miqaats/index', ['miqaats' => $miqaats]);
  }

  public function createForm(Request $request, Response $response): Response
  {
    return \view($response, 'admin/create_miqaat');
  }

  public function store(Request $request, Response $response): Response
  {
    $data = $request->getParsedBody();

    // Basic validation
    $title = $data['title'] ?? null;
    $date = $data['date'] ?? null;
    $category = $data['category'] ?? null;
    if (!$title || !$date || !$category) {
      return \view($response, 'admin/create_miqaat', ['error' => 'Missing fields']);
    }

    $token = bin2hex(random_bytes(32));
    $createdBy = $_SESSION['user_id'] ?? null; // Get ID of logged in admin

    $stmt = $this->db->prepare(
      "INSERT INTO miqaats (title, miqaat_date, category, qr_token, created_by) VALUES (?, ?, ?, ?, ?)"
    );

    $stmt->execute([
      $title,
      $date,
      $category,
      $token,
      $createdBy
    ]);

    // Generate QR
    $this->generateQr($token);

    // Redirect to the QR view page instead of showing inline
    $id = $this->db->lastInsertId();
    return $response->withHeader('Location', \url("/admin/miqaat/qr/$id"))->withStatus(302);
  }

  public function editForm(Request $request, Response $response, $args): Response
  {
    $miqaatId = $args['id'];
    $stmt = $this->db->prepare("SELECT * FROM miqaats WHERE id = ?");
    $stmt->execute([$miqaatId]);
    $miqaat = $stmt->fetch();

    if (!$miqaat) {
      return $response->withHeader('Location', \url('/admin/miqaats'))->withStatus(302);
    }

    // Fetch existing attendees
    $stmt = $this->db->prepare("
      SELECT a.id, u.username, u.name, a.created_at, a.ip_address 
      FROM attendance a 
      JOIN users u ON a.user_id = u.id 
      WHERE a.miqaat_id = ?
      ORDER BY a.created_at DESC
    ");
    $stmt->execute([$miqaatId]);
    $attendees = $stmt->fetchAll();

    // Fetch all users for manual add dropdown
    // Exclude admins if you only want to track members
    $allUsers = $this->db->query("SELECT id, username, name FROM users WHERE role != 'admin' ORDER BY username ASC")->fetchAll();

    return \view($response, 'admin/miqaats/edit', [
      'miqaat' => $miqaat,
      'attendees' => $attendees,
      'allUsers' => $allUsers
    ]);
  }

  public function update(Request $request, Response $response, $args): Response
  {
    $data = $request->getParsedBody();
    $title = $data['title'] ?? null;
    $date = $data['date'] ?? null;
    $category = $data['category'] ?? null;

    if (!$title || !$date || !$category) {
      // Should show error, but for simplicity redirecting back
      return $response->withHeader('Location', \url("/admin/miqaat/edit/" . $args['id']))->withStatus(302);
    }

    $stmt = $this->db->prepare("UPDATE miqaats SET title = ?, miqaat_date = ?, category = ? WHERE id = ?");
    $stmt->execute([$title, $date, $category, $args['id']]);

    return $response->withHeader('Location', \url('/admin/miqaats'))->withStatus(302);
  }

  public function delete(Request $request, Response $response, $args): Response
  {
    // Delete associated attendance first
    $stmt = $this->db->prepare("DELETE FROM attendance WHERE miqaat_id = ?");
    $stmt->execute([$args['id']]);

    // Delete the miqaat
    $stmt = $this->db->prepare("DELETE FROM miqaats WHERE id = ?");
    $stmt->execute([$args['id']]);
    return $response->withHeader('Location', \url('/admin/miqaats'))->withStatus(302);
  }

  public function viewQr(Request $request, Response $response, $args): Response
  {
    $stmt = $this->db->prepare("SELECT * FROM miqaats WHERE id = ?");
    $stmt->execute([$args['id']]);
    $miqaat = $stmt->fetch();

    if (!$miqaat) {
      return $response->withHeader('Location', \url('/admin/miqaats'))->withStatus(302);
    }

    // Always regenerate to ensure it matches current logic (e.g. /mark/ URL)
    $this->generateQr($miqaat['qr_token']);

    return \view($response, 'admin/miqaats/qr', ['miqaat' => $miqaat]);
  }

  public function publicQrView(Request $request, Response $response, $args): Response
  {
    $token = $args['token'];
    $stmt = $this->db->prepare("SELECT * FROM miqaats WHERE qr_token = ?");
    $stmt->execute([$token]);
    $miqaat = $stmt->fetch();

    if (!$miqaat) {
      return $response->withHeader('Location', \url('/login'))->withStatus(302);
    }

    // Always regenerate to ensure it matches current logic
    $this->generateQr($token);

    return \view($response, 'miqaats/public_qr', ['miqaat' => $miqaat]);
  }

  private function generateQr($token)
  {
    // The QR Code should link to the MARKING action.
    // The previous implementation linked to /{token}, which we are now repurposing as the "View Page".
    // We will now link to /mark/{token} which specifically handles attendance marking.
    $appBase = rtrim(getenv('APP_BASE') ?: 'https://tolobasaleh.com/attendance', '/');
    $actionUrl = $appBase . '/mark/' . $token;

    $builder = new Builder();
    $result = $builder->build(
      /* writer */ null,
      /* writerOptions */ null,
      /* validateResult */ false,
      /* data */ $actionUrl,
      /* encoding */ null,
      /* errorCorrectionLevel */ null,
      /* size */ 300
    );
    $result->saveToFile(__DIR__ . "/../../public/qrcodes/$token.png");
  }

  public function addAttendance(Request $req, Response $res, $args): Response
  {
    $miqaatId = $args['id'];
    $data = $req->getParsedBody();
    $userId = $data['user_id'] ?? null;

    if ($userId) {
      // Check if already exists to prevent duplicates (though DB might not constrain it, UI should be clean)
      $check = $this->db->prepare("SELECT id FROM attendance WHERE miqaat_id = ? AND user_id = ?");
      $check->execute([$miqaatId, $userId]);
      if (!$check->fetch()) {
        $stmt = $this->db->prepare("INSERT INTO attendance (miqaat_id, user_id, created_at, ip_address) VALUES (?, ?, ?, ?)");
        // Use current time, IP 'Manual'
        $stmt->execute([$miqaatId, $userId, date('Y-m-d H:i:s'), 'Manual']);
      }
    }

    return $res->withHeader('Location', \url('/admin/miqaat/edit/' . $miqaatId))->withStatus(302);
  }

  public function deleteAttendance(Request $req, Response $res, $args): Response
  {
    $attendanceId = $args['id'];
    $data = $req->getParsedBody();
    $miqaatId = $data['miqaat_id']; // Passed from hidden field

    $stmt = $this->db->prepare("DELETE FROM attendance WHERE id = ?");
    $stmt->execute([$attendanceId]);

    return $res->withHeader('Location', \url('/admin/miqaat/edit/' . $miqaatId))->withStatus(302);
  }
}
