<?php
namespace App\Controllers;

use PDO;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;

use App\Services\MailService;


class AdminController
{
    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function dashboard(Request $req, Response $res): Response
    {
        // Count stats
        $miqaats = $this->db->query("SELECT COUNT(*) FROM miqaats")->fetchColumn();
        $users = $this->db->query("SELECT COUNT(*) FROM users")->fetchColumn();
        $attendance = $this->db->query("SELECT COUNT(*) FROM attendance")->fetchColumn();

        // Recent attendance
        $recent = $this->db->query("
      SELECT a.*, u.username, m.title as miqaat_title 
      FROM attendance a 
      JOIN users u ON a.user_id = u.id 
      JOIN miqaats m ON a.miqaat_id = m.id 
      ORDER BY a.created_at DESC LIMIT 5
    ")->fetchAll();

        return \view($res, 'admin/dashboard', [
            'stats' => compact('miqaats', 'users', 'attendance'),
            'recent' => $recent
        ]);
    }

    public function listUsers(Request $req, Response $res): Response
    {
        $users = $this->db->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll();
        return \view($res, 'admin/users/index', ['users' => $users]);
    }

    public function createUserForm(Request $req, Response $res): Response
    {
        return \view($res, 'admin/users/create');
    }

    public function storeUser(Request $req, Response $res): Response
    {
        $data = $req->getParsedBody();
        $username = trim($data['username'] ?? '');
        $name = trim($data['name'] ?? '');
        $email = trim($data['email'] ?? '');
        $password = $data['password'] ?? '';
        $role = $data['role'] ?? 'member';

        if (!$username || !$password) {
            return \view($res, 'admin/users/create', ['error' => 'ITS (Username) and password required']);
        }

        // Validate strictly 8 digit ITS
        if (!preg_match('/^\d{8}$/', $username)) {
            return \view($res, 'admin/users/create', ['error' => 'ITS Number must be exactly 8 digits']);
        }

        $hash = password_hash($password, PASSWORD_BCRYPT);

        try {
            $stmt = $this->db->prepare("INSERT INTO users (username, name, email, password_hash, role) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$username, $name, $email, $hash, $role]);

            // Send Email Notification
            if ($email) {
                $subject = "Welcome to Toloba Saleh Attendance System";
                $message = "Hello $name,\n\nYour account has been created successfully.\n\nITS Number: $username\nPassword: $password\n\nYou can now login to mark your attendance.\n\nRegards,\nAdmin";
                $headers = "From: no-reply@tolobasaleh.com";
                // Suppress errors if mail not configured locally
                @mail($email, $subject, $message, $headers);
            }

            return $res->withHeader('Location', \url('/admin/users'))->withStatus(302);
        } catch (\PDOException $e) {
            return \view($res, 'admin/users/create', ['error' => 'Username likely taken or Database error']);
        }
    }

    public function editUserForm(Request $req, Response $res, $args): Response
    {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$args['id']]);
        $user = $stmt->fetch();
        return \view($res, 'admin/users/edit', ['user' => $user]);
    }

    public function updateUser(Request $req, Response $res, $args): Response
    {
        $data = $req->getParsedBody();
        $name = trim($data['name'] ?? '');
        $email = trim($data['email'] ?? '');
        $role = $data['role'] ?? 'member';
        $password = $data['password'] ?? null;

        $userSql = "SELECT * FROM users WHERE id = ?";
        $stmt = $this->db->prepare($userSql);
        $stmt->execute([$args['id']]);
        $existingUser = $stmt->fetch();

        // Only update password if provided
        if ($password) {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $this->db->prepare("UPDATE users SET name = ?, email = ?, role = ?, password_hash = ? WHERE id = ?");
            $stmt->execute([$name, $email, $role, $hash, $args['id']]);
            $msgDetails = "New Password: $password";
        } else {
            $stmt = $this->db->prepare("UPDATE users SET name = ?, email = ?, role = ? WHERE id = ?");
            $stmt->execute([$name, $email, $role, $args['id']]);
            $msgDetails = "(Password unchanged)";
        }

        // Send Email Notification on Account Update
        if ($email) {
            $subject = "Account Updated - Toloba Saleh Attendance";
            $message = "Hello $name,\n\nYour account details have been updated.\n\nITS Number: {$existingUser['username']}\n$msgDetails\n\nRegards,\nAdmin";
            MailService::send($email, $subject, $message);
        }

        return $res->withHeader('Location', \url('/admin/users'))->withStatus(302);
    }

    public function deleteUser(Request $req, Response $res, $args): Response
    {
        $stmt = $this->db->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$args['id']]);
        return $res->withHeader('Location', \url('/admin/users'))->withStatus(302);
    }

    public function reports(Request $req, Response $res): Response
    {
        // 1. Fetch available options for filters (Exclude 'admin' role or 'admin' username)
        $allMiqaats = $this->db->query("SELECT id, title, miqaat_date FROM miqaats ORDER BY miqaat_date DESC")->fetchAll();
        $allUsers = $this->db->query("
            SELECT id, username, name 
            FROM users 
            WHERE role != 'admin' AND username != 'admin' 
            ORDER BY username ASC
        ")->fetchAll();

        // 2. Handle Filters
        $params = $req->getQueryParams();
        $selectedMiqaats = $params['miqaat_ids'] ?? []; // Array of IDs
        $selectedUsers = $params['user_ids'] ?? [];     // Array of IDs

        $attendanceData = [];

        // 3. Build Query if filters are active
        $sql = "
            SELECT a.created_at, a.ip_address, u.username, u.name, m.title as miqaat_title, m.category, m.miqaat_date
            FROM attendance a
            JOIN users u ON a.user_id = u.id
            JOIN miqaats m ON a.miqaat_id = m.id
            WHERE 1=1
        ";

        // Exclude admin attendance from general reports if desired, usually better to see only members
        // $sql .= " AND u.role != 'admin'"; 

        $values = [];

        if (!empty($selectedMiqaats)) {
            $placeholders = implode(',', array_fill(0, count($selectedMiqaats), '?'));
            $sql .= " AND m.id IN ($placeholders)";
            $values = array_merge($values, $selectedMiqaats);
        }

        if (!empty($selectedUsers)) {
            $placeholders = implode(',', array_fill(0, count($selectedUsers), '?'));
            $sql .= " AND u.id IN ($placeholders)";
            $values = array_merge($values, $selectedUsers);
        }

        $sql .= " ORDER BY a.created_at DESC";

        if (empty($selectedMiqaats) && empty($selectedUsers)) {
            $sql .= " LIMIT 100";
        }

        $stmt = $this->db->prepare($sql);
        $stmt->execute($values);
        $attendanceData = $stmt->fetchAll();

        // 4. Aggregate data for Charts and Leaderboard
        $miqaatCounts = [];
        $userCounts = [];
        $userObjects = []; // Map username -> info

        foreach ($attendanceData as $row) {
            $mTitle = $row['miqaat_title'];
            $uName = $row['username']; // use ITS/username as key

            if (!isset($miqaatCounts[$mTitle]))
                $miqaatCounts[$mTitle] = 0;
            $miqaatCounts[$mTitle]++;

            if (!isset($userCounts[$uName])) {
                $userCounts[$uName] = 0;
                $userObjects[$uName] = [
                    'username' => $row['username'],
                    'name' => $row['name']
                ];
            }
            $userCounts[$uName]++;
        }

        arsort($miqaatCounts);
        arsort($userCounts);

        $topMiqaats = array_slice($miqaatCounts, 0, 20);
        $topUsers = array_slice($userCounts, 0, 20);

        $chartMiqaats = ['labels' => array_keys($topMiqaats), 'data' => array_values($topMiqaats)];
        $chartUsers = ['labels' => array_keys($topUsers), 'data' => array_values($topUsers)];

        // Prepare Leaderboard (Full sorted list)
        $leaderboard = [];
        foreach ($userCounts as $uName => $count) {
            if (isset($userObjects[$uName])) {
                $leaderboard[] = [
                    'username' => $userObjects[$uName]['username'],
                    'name' => $userObjects[$uName]['name'],
                    'count' => $count
                ];
            }
        }

        $miqaatSummary = $this->db->query("
          SELECT m.*, COUNT(a.id) as attendance_count 
          FROM miqaats m 
          LEFT JOIN attendance a ON m.id = a.miqaat_id 
          GROUP BY m.id 
          ORDER BY m.miqaat_date DESC
        ")->fetchAll();

        return \view($res, 'admin/reports', [
            'miqaats' => $miqaatSummary,
            'all_miqaats' => $allMiqaats,
            'all_users' => $allUsers,
            'attendance_data' => $attendanceData,
            'selected_miqaats' => $selectedMiqaats,
            'selected_users' => $selectedUsers,
            'chart_miqaats' => $chartMiqaats,
            'chart_users' => $chartUsers,
            'leaderboard' => $leaderboard
        ]);
    }

    public function viewMiqaatReport(Request $req, Response $res, $args): Response
    {
        $miqaatId = $args['id'];

        $stmt = $this->db->prepare("SELECT * FROM miqaats WHERE id = ?");
        $stmt->execute([$miqaatId]);
        $miqaat = $stmt->fetch();

        $stmt = $this->db->prepare("
      SELECT u.username, a.created_at, a.ip_address 
      FROM attendance a 
      JOIN users u ON a.user_id = u.id 
      WHERE a.miqaat_id = ?
      ORDER BY a.created_at ASC
    ");
        $stmt->execute([$miqaatId]);
        $attendees = $stmt->fetchAll();

        return \view($res, 'admin/report_miqaat', ['miqaat' => $miqaat, 'attendees' => $attendees]);
    }
}
