<?php
namespace App\Controllers;

use PDO;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;

class AuthController
{
  private $pdoFactory;

  public function __construct(?callable $pdoFactory = null)
  {
    $this->pdoFactory = $pdoFactory;
  }

  public function showLogin(Request $req, Response $res): Response
  {
    $notice = $req->getQueryParams()['notice'] ?? null;
    return \view($res, 'auth/login', ['notice' => $notice]);
  }

  public function login(Request $req, Response $res): Response
  {
    $data = $req->getParsedBody();

    $db = null;
    if (is_callable($this->pdoFactory)) {
      try {
        $db = ($this->pdoFactory)();
      } catch (\PDOException $e) {
        return \view($res, 'auth/login', ['error' => 'Database unavailable']);
      }
    }

    if (!$db) {
      return \view($res, 'auth/login', ['error' => 'Database unavailable']);
    }

    $stmt = $db->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$data['username']]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($data['password'], $user['password_hash'])) {
      return \view($res, 'auth/login', ['error' => 'Invalid credentials']);
    }

    $_SESSION['user_id'] = $user['id'];
    $_SESSION['role'] = $user['role'];

    if ($user['role'] === 'admin') {
      return $res->withHeader('Location', \url('/admin'))->withStatus(302);
    }

    $queryParams = $req->getQueryParams();
    if (isset($queryParams['redirect'])) {
      return $res->withHeader('Location', $queryParams['redirect'])->withStatus(302);
    }

    return \view($res, 'attendance/result', ['message' => 'Logged in']);
  }

  public function logout(Request $req, Response $res): Response
  {
    session_destroy();
    return $res->withHeader('Location', \url('/login'))->withStatus(302);
  }
}
