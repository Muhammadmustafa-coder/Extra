<?php
namespace App\Services;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class MailService
{
    public static function send($to, $subject, $body)
    {
        $mail = new PHPMailer(true);

        // Helper to safely get env vars
        $env = function ($key, $default = '') {
            return $_ENV[$key] ?? getenv($key) ?: $default;
        };

        try {
            // Server settings
            $mail->isSMTP();
            $mail->Host = $env('SMTP_HOST', 'smtp.gmail.com');
            $mail->SMTPAuth = true;
            $mail->Username = $env('SMTP_USER');
            $mail->Password = $env('SMTP_PASS');
            $mail->SMTPSecure = $env('SMTP_SECURE', PHPMailer::ENCRYPTION_SMTPS);
            $mail->Port = $env('SMTP_PORT', 465);

            // Recipients
            $fromEmail = $env('SMTP_FROM_EMAIL', 'no-reply@tolobasaleh.com');
            $fromName = $env('SMTP_FROM_NAME', 'Toloba Saleh Admin');

            $mail->setFrom($fromEmail, $fromName);
            $mail->addAddress($to);

            // Content
            $mail->isHTML(false);
            $mail->Subject = $subject;
            $mail->Body = $body;

            $mail->send();
            return true;
        } catch (Exception $e) {
            $logFile = dirname(__DIR__, 2) . '/email_error.log';
            $timestamp = date('Y-m-d H:i:s');
            file_put_contents($logFile, "[$timestamp] Mail Error: {$mail->ErrorInfo}\n", FILE_APPEND);
            return false;
        }
    }
}
