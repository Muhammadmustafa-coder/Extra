<?php
function view($response, $path, $data = [])
{
  extract($data);
  ob_start();
  require __DIR__ . "/../views/$path.php";
  $response->getBody()->write(ob_get_clean());
  return $response;
}


function get_base_path(): string
{
  return getenv('APP_BASE_PATH') ?: '/attendance';
}

function asset(string $path): string
{
  // Assets are in the public folder.
  // We need to explicitly include /public because the .htaccess doesn't automatically map 
  // root-level static file requests to the public folder for direct file serving.
  $base = get_base_path();

  if ($path === '' || $path[0] !== '/') {
    $path = '/' . ltrim($path, '/');
  }

  // Return /attendance/public/css/style.css
  return rtrim($base, '/') . '/public' . $path;
}

function url(string $path): string
{
  // Routes should NOT have /public in them, as .htaccess rewrites them to index.php
  $base = get_base_path();

  if ($path === '' || $path[0] !== '/') {
    $path = '/' . ltrim($path, '/');
  }

  return rtrim($base, '/') . $path;
}
