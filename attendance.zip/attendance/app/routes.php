<?php
use Slim\Routing\RouteCollectorProxy;
use App\Controllers\AuthController;
use App\Controllers\MiqaatController;
use App\Controllers\AttendanceController;
use App\Controllers\AdminController;

$app->get('/', function ($request, $response, $args) {
  if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
    return $response->withHeader('Location', \url('/admin'))->withStatus(302);
  }
  return $response->withHeader('Location', \url('/login'))->withStatus(302);
});

$app->get('/login', [AuthController::class, 'showLogin']);
$app->post('/login', [AuthController::class, 'login']);
$app->get('/logout', [AuthController::class, 'logout']);

// Public View for QR Code
$app->get('/{token:[a-f0-9]{64}}', [MiqaatController::class, 'publicQrView']);

// Attendance Marking (Auth handled inside controller to support custom messages)
$app->get('/mark/{token:[a-f0-9]{64}}', [AttendanceController::class, 'mark']);


$app->group('/admin', function (RouteCollectorProxy $group) {
  $group->get('', [AdminController::class, 'dashboard']);

  // Miqaats Management
  $group->get('/miqaats', [MiqaatController::class, 'index']);
  $group->get('/miqaat/create', [MiqaatController::class, 'createForm']);
  $group->post('/miqaat/create', [MiqaatController::class, 'store']);
  $group->get('/miqaat/edit/{id}', [MiqaatController::class, 'editForm']);
  $group->post('/miqaat/edit/{id}', [MiqaatController::class, 'update']);
  $group->get('/miqaat/delete/{id}', [MiqaatController::class, 'delete']);
  $group->get('/miqaat/qr/{id}', [MiqaatController::class, 'viewQr']);

  // Miqaat Attendance Management
  $group->post('/miqaat/attendance/add/{id}', [MiqaatController::class, 'addAttendance']);
  $group->post('/miqaat/attendance/delete/{id}', [MiqaatController::class, 'deleteAttendance']);

  // Users
  $group->get('/users', [AdminController::class, 'listUsers']);
  $group->get('/users/create', [AdminController::class, 'createUserForm']);
  $group->post('/users/create', [AdminController::class, 'storeUser']);
  $group->get('/users/edit/{id}', [AdminController::class, 'editUserForm']);
  $group->post('/users/edit/{id}', [AdminController::class, 'updateUser']); // Used for update and reset password
  $group->get('/users/delete/{id}', [AdminController::class, 'deleteUser']);

  // Reports
  $group->get('/reports', [AdminController::class, 'reports']);
  $group->get('/reports/miqaat/{id}', [AdminController::class, 'viewMiqaatReport']);

})->add($adminMiddleware);
