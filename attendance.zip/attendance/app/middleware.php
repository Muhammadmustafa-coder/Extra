<?php
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Server\RequestHandlerInterface as Handler;

$authMiddleware = function (Request $req, Handler $handler) {
  if (!isset($_SESSION['user_id'])) {
    $uri = $req->getUri()->getPath();
    return (new Slim\Psr7\Response())
      ->withHeader('Location', \url('/login?redirect=' . urlencode($uri)))
      ->withStatus(302);
  }
  return $handler->handle($req);
};

$adminMiddleware = function (Request $req, Handler $handler) {
  if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    return (new Slim\Psr7\Response())
      ->withHeader('Location', \url('/login'))
      ->withStatus(302);
  }
  return $handler->handle($req);
};
