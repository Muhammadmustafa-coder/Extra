<?php

// Attempt to load .env using vlucas/phpdotenv if available.
$projectRoot = dirname(__DIR__);
$autoload = $projectRoot . '/vendor/autoload.php';
if (file_exists($autoload)) {
  require_once $autoload;
  if (class_exists(\Dotenv\Dotenv::class)) {
    try {
      $dotenv = Dotenv\Dotenv::createImmutable($projectRoot);
      $dotenv->safeLoad(); // safeLoad won't throw if .env is missing
    } catch (Throwable $e) {
      // ignore dotenv load errors; fallback to environment
    }
  }
}

return function () {
  $host = $_ENV['DB_HOST'] ?? getenv('DB_HOST') ?: 'localhost';
  $db = $_ENV['DB_NAME'] ?? getenv('DB_NAME') ?: 'aunarodi_attendance_system';
  $user = $_ENV['DB_USER'] ?? getenv('DB_USER') ?: 'aunarodi_site';
  $pass = $_ENV['DB_PASS'] ?? getenv('DB_PASS') ?: 'wFzH?pFp=2Ig';

  return new PDO(
    "mysql:host={$host};dbname={$db};charset=utf8mb4",
    $user,
    $pass,
    [
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]
  );
};
