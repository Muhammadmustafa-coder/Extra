<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login</title>
  <link rel="stylesheet" href="<?= htmlspecialchars(asset('/css/styles.css')) ?>">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
</head>

<body>
  <div class="app">
    <main class="center-card card">
      <div class="brand" style="justify-content:center;margin-bottom:1rem">
        <h1 style="margin:0;font-size:1.5rem">Attendance System</h1>
      </div>
      <p class="text-muted" style="margin-bottom:1.5rem;text-align:center">Sign in to your account</p>

      <?php if (!empty($notice)): ?>
        <div class="alert alert-success"><?= htmlspecialchars($notice) ?></div>
      <?php endif; ?>

      <?php if (!empty($error)): ?>
        <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <!-- Post to current URL to preserve query params like redirect -->
      <form method="post" action="">
        <div class="form-group">
          <label class="form-label">Username</label>
          <input type="text" name="username" class="form-control" placeholder="Enter username" required>
        </div>
        <div class="form-group">
          <label class="form-label">Password</label>
          <input type="password" name="password" class="form-control" placeholder="Enter password" required>
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%">Sign In</button>
      </form>
    </main>
  </div>
</body>

</html>