<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Attendance</title>
  <link rel="stylesheet" href="<?= htmlspecialchars(asset('/css/styles.css')) ?>">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
</head>

<body>
  <div class="app">
    <main class="center-card card" style="text-align:center">
      <?php
      $status = $status ?? 'success';
      $icon = match ($status) {
        'error' => '❌',
        'warning' => '⚠️',
        default => '✅'
      };
      $title = match ($status) {
        'error' => 'Error',
        'warning' => 'Notice',
        default => 'Success'
      };
      ?>
      <div style="font-size:3rem;margin-bottom:1rem"><?= $icon ?></div>
      <h2 style="margin-bottom:0.5rem"><?= $title ?></h2>
      <p class="text-muted" style="font-size:1.1rem"><?= htmlspecialchars($message) ?></p>

      <div style="margin-top:2rem">
        <a href="<?= htmlspecialchars(url('/logout')) ?>" class="btn btn-secondary btn-sm">Logout</a>
      </div>
    </main>
  </div>
</body>

</html>