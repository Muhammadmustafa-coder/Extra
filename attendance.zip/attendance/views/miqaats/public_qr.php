<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        <?= htmlspecialchars($miqaat['title']) ?> - Scan to Mark Attendance
    </title>
    <link rel="stylesheet" href="<?= htmlspecialchars(asset('/css/styles.css')) ?>">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
</head>

<body>
    <div class="app">
        <main class="center-card card" style="text-align:center; max-width: 600px;">
            <h1 style="font-size:2rem;margin-bottom:0.5rem">
                <?= htmlspecialchars($miqaat['title']) ?>
            </h1>
            <p class="text-muted" style="margin-bottom:2rem">
                <?= date('d-m-Y', strtotime($miqaat['miqaat_date'])) ?> •
                <?= ucfirst($miqaat['category']) ?>
            </p>

            <div class="qr-container" style="padding:2rem;margin-bottom:2rem;box-shadow:0 8px 30px rgba(0,0,0,0.12)">
                <img src="<?= htmlspecialchars(asset('/qrcodes/' . $miqaat['qr_token'] . '.png')) ?>" alt="QR Code"
                    style="width:100%;max-width:350px">
            </div>

            <p style="font-size:1.25rem;font-weight:600;color:var(--primary)">Scan with your phone to mark attendance
            </p>
        </main>
    </div>
</body>

</html>