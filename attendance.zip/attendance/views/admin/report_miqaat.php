<?php include __DIR__ . '/header.php'; ?>

<div class="header-bar">
    <h2>Report:
        <?= htmlspecialchars($miqaat['title']) ?>
    </h2>
    <a href="<?= htmlspecialchars(url('/admin/reports')) ?>" class="btn btn-secondary">Back</a>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <span class="stat-label">Date</span>
        <span class="stat-value" style="font-size:1.5rem">
            <?= $miqaat['miqaat_date'] ?>
        </span>
    </div>
    <div class="stat-card">
        <span class="stat-label">Category</span>
        <span class="stat-value" style="font-size:1.5rem">
            <?= htmlspecialchars($miqaat['category']) ?>
        </span>
    </div>
    <div class="stat-card">
        <span class="stat-label">Total Attendees</span>
        <span class="stat-value">
            <?= count($attendees) ?>
        </span>
    </div>
</div>

<div class="card">
    <h3 class="card-title">Attendee List</h3>
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>User</th>
                    <th>Time Marked</th>
                    <th>IP Address</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($attendees as $i => $a): ?>
                    <tr>
                        <td>
                            <?= $i + 1 ?>
                        </td>
                        <td>
                            <?= htmlspecialchars($a['username']) ?>
                        </td>
                        <td>
                            <?= $a['created_at'] ?>
                        </td>
                        <td>
                            <?= $a['ip_address'] ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($attendees)): ?>
                    <tr>
                        <td colspan="4" class="text-muted">No attendees yet</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include __DIR__ . '/footer.php'; ?>