<?php include __DIR__ . '/header.php'; ?>

<div class="header-bar">
  <h2>Create Miqaat</h2>
  <a href="<?= htmlspecialchars(url('/admin')) ?>" class="btn btn-secondary">Back</a>
</div>

<div class="center-card">
  <div class="card">
    <form method="post" action="<?= htmlspecialchars(url('/admin/miqaat/create')) ?>">
      <div class="form-group">
        <label class="form-label">Miqaat Title</label>
        <input type="text" name="title" class="form-control" placeholder="e.g. Weekly Majlis" required>
      </div>
      <div class="form-group">
        <label class="form-label">Date</label>
        <input type="date" name="date" class="form-control" required>
      </div>
      <div class="form-group">
        <label class="form-label">Category</label>
        <select name="category" class="form-control">
          <option value="local">Local</option>
          <option value="central">Central</option>
        </select>
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%">Create Miqaat</button>
    </form>
  </div>

  <?php if (isset($qr)): ?>
    <div class="card mt-4">
      <h3>QR Code Generated</h3>
      <p class="text-muted">Scan this code to mark attendance.</p>
      <div class="qr-container">
        <img src="<?= htmlspecialchars(asset('/qrcodes/' . $qr . '.png')) ?>" alt="QR Code">
      </div>
      <div class="mt-4">
        <a href="<?= htmlspecialchars(asset('/qrcodes/' . $qr . '.png')) ?>" download="miqaat_qr_<?= $qr ?>.png"
          class="btn btn-secondary btn-sm">Download
          QR</a>
      </div>
    </div>
  <?php endif; ?>
</div>

<?php include __DIR__ . '/footer.php'; ?>