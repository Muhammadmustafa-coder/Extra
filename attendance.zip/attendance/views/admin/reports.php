<?php include __DIR__ . '/header.php'; ?>

<div class="header-bar">
    <h2>Reports & Analytics</h2>
</div>

<!-- Filters -->
<!-- Filters -->
<div class="card" style="position: relative; z-index: 50; overflow: visible;">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem">
        <h3 class="card-title" style="margin:0">Filter Data</h3>
        <span style="font-size:0.85rem;color:var(--text-muted)">Search and select multiple options</span>
    </div>

    <form method="get" action="<?= htmlspecialchars(url('/admin/reports')) ?>">
        <div class="stats-grid"
            style="align-items: end; margin-bottom:0; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));">
            <div class="form-group" style="margin-bottom:0;">
                <label class="form-label">Members</label>
                <select id="select-users" name="user_ids[]" multiple placeholder="Type to search members..."
                    autocomplete="off">
                    <?php foreach ($all_users as $u): ?>
                        <option value="<?= $u['id'] ?>" <?= in_array($u['id'], $selected_users) ? 'selected' : '' ?>>
                            <?php
                            $displayName = !empty($u['name']) ? $u['name'] . ' (' . $u['username'] . ')' : $u['username'];
                            echo htmlspecialchars($displayName);
                            ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group" style="margin-bottom:0;">
                <label class="form-label">Miqaats (Events)</label>
                <select id="select-miqaats" name="miqaat_ids[]" multiple placeholder="Type to search events..."
                    autocomplete="off">
                    <?php foreach ($all_miqaats as $m): ?>
                        <option value="<?= $m['id'] ?>" <?= in_array($m['id'], $selected_miqaats) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($m['title']) ?> (<?= $m['miqaat_date'] ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div style="display:flex;gap:0.5rem;align-self:end;margin-bottom:0.25rem">
                <button type="submit" class="btn btn-primary" style="height:42px">Apply Filters</button>
                <a href="<?= htmlspecialchars(url('/admin/reports')) ?>" class="btn btn-secondary"
                    style="height:42px">Reset</a>
            </div>
        </div>
    </form>
</div>

<!-- Tom Select Resources -->
<link href="https://cdn.jsdelivr.net/npm/tom-select@2.2.2/dist/css/tom-select.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/tom-select@2.2.2/dist/js/tom-select.complete.min.js"></script>
<style>
    /* Premium overrides for Tom Select */
    .ts-control {
        border-radius: 10px !important;
        padding: 10px 12px !important;
        border-color: var(--border-color) !important;
        box-shadow: none !important;
        background: #fff !important;
        font-family: inherit !important;
        min-height: 48px;
    }

    .ts-control.focus {
        border-color: var(--primary) !important;
        box-shadow: 0 0 0 3px var(--accent) !important;
    }

    .ts-wrapper.multi .ts-control>div {
        background: var(--primary) !important;
        color: white !important;
        border-radius: 6px !important;
        padding: 2px 8px !important;
    }

    .ts-dropdown {
        border-radius: 10px !important;
        box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1) !important;
        border: 1px solid var(--border-color) !important;
        margin-top: 8px !important;
        padding: 0 !important;
        overflow: hidden !important;
        z-index: 100 !important;
    }

    .ts-dropdown .active {
        background: var(--accent) !important;
        color: var(--primary-600) !important;
    }

    .ts-dropdown .option {
        padding: 10px 12px !important;
    }
</style>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        new TomSelect("#select-users", {
            plugins: ['remove_button'],
            maxOptions: 50,
            render: {
                item: function (data, escape) {
                    return '<div>' + escape(data.text) + '</div>';
                }
            }
        });
        new TomSelect("#select-miqaats", {
            plugins: ['remove_button'],
            maxOptions: 50
        });
    });
</script>

<!-- Charts Section -->
<div class="stats-grid" style="grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 2rem;">
    <div class="card" style="margin-bottom:0">
        <h3 class="card-title">Attendance by Member</h3>
        <div style="position: relative; height: 300px; width: 100%;">
            <canvas id="chartUsers"></canvas>
        </div>
    </div>
    <div class="card" style="margin-bottom:0">
        <h3 class="card-title">Attendance by Miqaat</h3>
        <div style="position: relative; height: 300px; width: 100%;">
            <canvas id="chartMiqaats"></canvas>
        </div>
    </div>
</div>

<!-- Detailed Logs -->
<div class="card" style="margin-top: 2rem;">
    <div style="display:flex;justify-content:space-between;align-items:center;">
        <h3 class="card-title">Top Members</h3>
        <select class="form-control" style="width: auto;" onchange="updateLeaderboardLimit(this.value)">
            <option value="5">Top 5</option>
            <option value="10" selected>Top 10</option>
            <option value="20">Top 20</option>
            <option value="1000">All</option>
        </select>
    </div>
    <div class="table-responsive">
        <table class="data-table" id="leaderboard-table">
            <thead>
                <tr>
                    <th width="50">Rank</th>
                    <th>Member</th>
                    <th>Attendance Count</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $rank = 1;
                foreach ($leaderboard as $l):
                    $isHidden = $rank > 10 ? 'style="display:none"' : '';
                    ?>
                    <tr class="leaderboard-row" data-rank="<?= $rank ?>" <?= $isHidden ?>>
                        <td>#<?= $rank++ ?></td>
                        <td>
                            <?php
                            $lName = htmlspecialchars($l['name'] ?? '');
                            $lUser = htmlspecialchars($l['username']);
                            echo $lName ? "<b>$lName</b> <span class='text-muted'>($lUser)</span>" : "<b>$lUser</b>";
                            ?>
                        </td>
                        <td>
                            <span class="badge badge-success"><?= $l['count'] ?></span>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($leaderboard)): ?>
                    <tr>
                        <td colspan="3" class="text-center text-muted">No attendance data yet.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    function updateLeaderboardLimit(limit) {
        const rows = document.querySelectorAll('.leaderboard-row');
        rows.forEach(row => {
            const rank = parseInt(row.getAttribute('data-rank'));
            if (rank <= limit) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }
</script>

<div class="card" style="margin-top: 2rem;">
    <h3 class="card-title">Attendance Details</h3>
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Member</th>
                    <th>Miqaat</th>
                    <th>Details</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($attendance_data as $row): ?>
                    <tr>
                        <td style="font-weight:600;color:var(--text-muted)">
                            <?= date('d-m-Y H:i', strtotime($row['created_at'])) ?>
                        </td>
                        <td>
                            <div style="display:flex;align-items:center;gap:0.5rem">
                                <span
                                    style="width:24px;height:24px;background:#e2e8f0;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:0.75rem">👤</span>
                                <div>
                                    <?php
                                    $dName = htmlspecialchars($row['name'] ?? '');
                                    $dUser = htmlspecialchars($row['username']);
                                    echo $dName ? "$dName <span style='color:var(--text-muted);font-size:0.8em'>($dUser)</span>" : $dUser;
                                    ?>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div style="font-weight:600"><?= htmlspecialchars($row['miqaat_title']) ?></div>
                            <div style="font-size:0.8rem;color:var(--text-muted)"><?= ucfirst($row['category']) ?></div>
                        </td>
                        <td style="font-family:monospace;font-size:0.85rem"><?= $row['ip_address'] ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($attendance_data)): ?>
                    <tr>
                        <td colspan="4" class="text-muted" style="text-align:center;padding:2rem">No records found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Scrip for Charts -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const chartConfig = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: { beginAtZero: true, ticks: { precision: 0 } },
                x: { grid: { display: false } }
            }
        };

        // User Chart
        const ctxUsers = document.getElementById('chartUsers').getContext('2d');
        new Chart(ctxUsers, {
            type: 'bar',
            data: {
                labels: <?= json_encode($chart_users['labels']) ?>,
                datasets: [{
                    label: 'Attendance Count',
                    data: <?= json_encode($chart_users['data']) ?>,
                    backgroundColor: 'rgba(0, 102, 13, 0.6)',
                    borderColor: 'rgba(0, 102, 13, 1)',
                    borderWidth: 1,
                    borderRadius: 4
                }]
            },
            options: { ...chartConfig, indexAxis: 'y' } // Horizontal bar for users names
        });

        // Miqaat Chart
        const ctxMiqaats = document.getElementById('chartMiqaats').getContext('2d');
        new Chart(ctxMiqaats, {
            type: 'bar',
            data: {
                labels: <?= json_encode($chart_miqaats['labels']) ?>,
                datasets: [{
                    label: 'Attendees',
                    data: <?= json_encode($chart_miqaats['data']) ?>,
                    backgroundColor: 'rgba(59, 130, 246, 0.6)',
                    borderColor: 'rgba(59, 130, 246, 1)',
                    borderWidth: 1,
                    borderRadius: 4
                }]
            },
            options: chartConfig
        });
    });
</script>

<?php include __DIR__ . '/footer.php'; ?>