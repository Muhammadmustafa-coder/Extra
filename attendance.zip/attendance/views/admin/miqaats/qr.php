<?php include __DIR__ . '/../header.php'; ?>

<div class="header-bar">
    <h2>QR Code:
        <?= htmlspecialchars($miqaat['title']) ?>
    </h2>
    <a href="<?= htmlspecialchars(url('/admin/miqaats')) ?>" class="btn btn-secondary">Back</a>
</div>

<div class="center-card" style="text-align:center">
    <div class="card">
        <p class="text-muted" style="margin-bottom:1.5rem">Scan this code to mark attendance.</p>

        <div class="qr-container" style="margin-bottom:1.5rem">
            <img src="<?= htmlspecialchars(asset('/qrcodes/' . $miqaat['qr_token'] . '.png')) ?>" alt="QR Code">
        </div>

        <div>
            <a href="<?= htmlspecialchars(asset('/qrcodes/' . $miqaat['qr_token'] . '.png')) ?>"
                download="miqaat_qty_<?= $miqaat['qr_token'] ?>.png" class="btn btn-primary">Download QR</a>
        </div>

        <div style="margin-top:2rem;text-align:left">
            <label class="form-label">Direct Link (Copy & Share)</label>
            <?php
            $tokenLink = rtrim(getenv('APP_BASE') ?: 'https://tolobasaleh.com/attendance', '/') . '/' . $miqaat['qr_token'];
            ?>
            <input type="text" class="form-control" value="<?= htmlspecialchars($tokenLink) ?>" readonly
                onclick="this.select()">
        </div>
    </div>
</div>

<?php include __DIR__ . '/../footer.php'; ?>