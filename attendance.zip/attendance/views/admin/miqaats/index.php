<?php include __DIR__ . '/../header.php'; ?>

<div class="header-bar">
    <div style="display:flex;align-items:center;gap:1rem">
        <h2 style="margin:0">Miqaats</h2>
        <a href="<?= htmlspecialchars(url('/admin/miqaat/create')) ?>" class="btn btn-sm btn-primary">Add New</a>
    </div>
</div>

<style>
    .wp-table {
        width: 100%;
        border-collapse: collapse;
        background: #fff;
        border: 1px solid #e2e8f0;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
    }

    .wp-table th,
    .wp-table td {
        padding: 0.75rem 1rem;
        text-align: left;
        border-bottom: 1px solid #e2e8f0;
        vertical-align: top;
    }

    .wp-table th {
        font-weight: 600;
        color: #1e293b;
        font-size: 0.875rem;
    }

    .wp-table tr:hover {
        background: #f8fafc;
    }

    .wp-table .row-title {
        color: var(--primary);
        font-weight: 600;
        font-size: 1rem;
        margin-bottom: 0.25rem;
        display: block;
    }

    .wp-table .row-actions {
        opacity: 0;
        transition: opacity 0.2s;
        font-size: 0.8rem;
        margin-top: 5px;
    }

    .wp-table tr:hover .row-actions {
        opacity: 1;
    }

    .wp-table .row-actions a {
        margin-right: 8px;
        color: var(--primary);
    }

    .wp-table .row-actions a.delete {
        color: #ef4444;
    }

    .filter-bar {
        display: flex;
        gap: 1rem;
        margin-bottom: 1rem;
        align-items: center;
        flex-wrap: wrap;
    }

    .badge-gray {
        background: #e2e8f0;
        color: #64748b;
        font-size: 0.75rem;
        padding: 2px 8px;
        border-radius: 4px;
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const mainCheckbox = document.querySelector('thead input[type="checkbox"]');
        const rowCheckboxes = document.querySelectorAll('tbody input[type="checkbox"]');

        if (mainCheckbox) {
            mainCheckbox.addEventListener('change', function () {
                rowCheckboxes.forEach(cb => {
                    cb.checked = mainCheckbox.checked;
                });
            });
        }
    });
</script>

<div class="filter-bar">
    <div style="color:var(--text-muted);font-size:0.9rem">All (<?= count($miqaats) ?>)</div>
    <div style="margin-left:auto; display:flex; gap:0.5rem">
        <select class="form-control" style="width: auto; padding: 0.4rem 2rem 0.4rem 0.8rem; height: auto;">
            <option>All dates</option>
        </select>
        <select class="form-control" style="width: auto; padding: 0.4rem 2rem 0.4rem 0.8rem; height: auto;">
            <option>All Categories</option>
        </select>
        <button class="btn btn-secondary btn-sm">Filter</button>
    </div>
</div>

<div class="table-responsive">
    <table class="wp-table">
        <thead>
            <tr>
                <th style="width: 20px;"><input type="checkbox"></th>
                <th>Title</th>
                <th>Author</th>
                <th>Category</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($miqaats as $m): ?>
                <tr>
                    <td><input type="checkbox"></td>
                    <td>
                        <span class="row-title"><?= htmlspecialchars($m['title']) ?></span>
                        <div class="row-actions">
                            <a href="<?= htmlspecialchars(url('/admin/miqaat/edit/' . $m['id'])) ?>">Edit / Attendance</a> |
                            <a href="<?= htmlspecialchars(url('/admin/miqaat/qr/' . $m['id'])) ?>">View QR</a> |
                            <a href="<?= htmlspecialchars(url('/admin/miqaat/delete/' . $m['id'])) ?>" class="delete"
                                onclick="return confirm('Delete miqaat?');">Delete</a>
                        </div>
                    </td>
                    <td>
                        <?= htmlspecialchars($m['creator_name'] ?? 'System') ?>
                    </td>
                    <td>
                        <?= htmlspecialchars(ucfirst($m['category'])) ?>
                    </td>
                    <td>
                        <div style="color:var(--text-muted); font-size:0.85rem">Published</div>
                        <?= date('d-m-Y', strtotime($m['miqaat_date'])) ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($miqaats)): ?>
                <tr>
                    <td colspan="5" class="text-muted" style="text-align:center; padding: 2rem;">No miqaats found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include __DIR__ . '/../footer.php'; ?>