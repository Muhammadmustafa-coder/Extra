<?php include __DIR__ . '/../header.php'; ?>

<div class="header-bar">
    <h2>Edit Miqaat</h2>
    <a href="<?= htmlspecialchars(url('/admin/miqaats')) ?>" class="btn btn-secondary">Back</a>
</div>

<div class="center-card" style="max-width: 1000px;">
    <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 2rem; align-items: start;">
        <!-- Left: Edit Miqaat Details -->
        <div class="card">
            <h3 class="card-title">Event Details</h3>
            <form method="post" action="<?= htmlspecialchars(url('/admin/miqaat/edit/' . $miqaat['id'])) ?>">
                <div class="form-group">
                    <label class="form-label">Miqaat Title</label>
                    <input type="text" name="title" class="form-control"
                        value="<?= htmlspecialchars($miqaat['title']) ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Date</label>
                    <input type="date" name="date" class="form-control" value="<?= $miqaat['miqaat_date'] ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Category</label>
                    <select name="category" class="form-control">
                        <option value="local" <?= $miqaat['category'] === 'local' ? 'selected' : '' ?>>Local</option>
                        <option value="central" <?= $miqaat['category'] === 'central' ? 'selected' : '' ?>>Central
                        </option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary" style="width:100%">Update Details</button>
            </form>
        </div>

        <!-- Right: Attendance Management -->
        <div class="card">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem">
                <h3 class="card-title" style="margin:0">Attendance (<?= count($attendees) ?>)</h3>
                <span class="badge badge-success">Live</span>
            </div>

            <!-- Add Attendee Form -->
            <form method="post" action="<?= htmlspecialchars(url('/admin/miqaat/attendance/add/' . $miqaat['id'])) ?>"
                style="background:#f8fafc;padding:1rem;border-radius:8px;margin-bottom:1.5rem;border:1px solid #e2e8f0;">
                <label class="form-label" style="font-size:0.85rem">Manually Add Attendee</label>
                <div style="display:flex;gap:0.5rem">
                    <select name="user_id" id="select-attendee" placeholder="Search member..." required>
                        <option value="">Select Member...</option>
                        <?php foreach ($allUsers as $u): ?>
                            <?php
                            $dName = !empty($u['name']) ? $u['name'] . ' (' . $u['username'] . ')' : $u['username'];
                            ?>
                            <option value="<?= $u['id'] ?>"><?= htmlspecialchars($dName) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" class="btn btn-primary btn-sm" style="white-space:nowrap">Add</button>
                </div>
            </form>

            <!-- Attendees List -->
            <div class="table-responsive" style="max-height: 500px; overflow-y: auto;">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Member</th>
                            <th>Time</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($attendees as $a): ?>
                            <tr>
                                <td>
                                    <div style="font-weight:600"><?= htmlspecialchars($a['name'] ?: $a['username']) ?></div>
                                    <div style="color:var(--text-muted);font-size:0.8rem">
                                        <?= htmlspecialchars($a['username']) ?></div>
                                </td>
                                <td style="font-size:0.85rem;color:var(--text-muted)">
                                    <?= date('d-M H:i', strtotime($a['created_at'])) ?>
                                </td>
                                <td>
                                    <form method="post"
                                        action="<?= htmlspecialchars(url('/admin/miqaat/attendance/delete/' . $a['id'])) ?>"
                                        onsubmit="return confirm('Remove attendance for <?= $a['username'] ?>?');">
                                        <input type="hidden" name="miqaat_id" value="<?= $miqaat['id'] ?>">
                                        <button type="submit" class="btn btn-sm"
                                            style="background:#fee2e2;color:#ef4444;border:none;padding:4px 8px;">
                                            ✕
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($attendees)): ?>
                            <tr>
                                <td colspan="3" class="text-center text-muted" style="padding:2rem">No attendees yet.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Tom Select for Searchable Dropdown -->
<link href="https://cdn.jsdelivr.net/npm/tom-select@2.2.2/dist/css/tom-select.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/tom-select@2.2.2/dist/js/tom-select.complete.min.js"></script>
<script>
    new TomSelect("#select-attendee", {
        create: false,
        sortField: {
            field: "text",
            direction: "asc"
        },
        maxOptions: 50
    });
</script>

<?php include __DIR__ . '/../footer.php'; ?>