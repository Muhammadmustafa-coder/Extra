<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Admin</title>
    <link rel="stylesheet" href="<?= htmlspecialchars(asset('/css/styles.css')) ?>">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 900;
        }

        .sidebar-overlay.active {
            display: block;
        }
    </style>
</head>

<body>
    <div class="sidebar-overlay" onclick="toggleSidebar()"></div>
    <div class="admin-layout">
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <img src="<?= htmlspecialchars(url('/images/newweblogo1.png')) ?>" alt="Admin Panel"
                    style="max-height: 67px; width: 100%;">
                <button class="mobile-menu-btn" style="margin-left:auto;color:#fff;font-size:1.5rem;"
                    onclick="toggleSidebar()">×</button>
            </div>
            <nav>
                <div class="nav-item"><a href="<?= htmlspecialchars(url('/admin')) ?>" class="nav-link">Dashboard</a>
                </div>
                <div class="nav-item"><a href="<?= htmlspecialchars(url('/admin/users')) ?>" class="nav-link">Users</a>
                </div>
                <div class="nav-item"><a href="<?= htmlspecialchars(url('/admin/miqaats')) ?>"
                        class="nav-link">Miqaats</a></div>
                <div class="nav-item"><a href="<?= htmlspecialchars(url('/admin/reports')) ?>"
                        class="nav-link">Reports</a></div>
                <div class="nav-item mt-4"><a href="<?= htmlspecialchars(url('/logout')) ?>" class="nav-link"
                        style="color:#ef4444">Logout</a></div>
            </nav>
        </aside>
        <main class="main-content">
            <div class="mobile-header" style="display:flex;align-items:center;margin-bottom:1rem">
                <button class="mobile-menu-btn" onclick="toggleSidebar()">☰</button>
            </div>
            <script>
                function toggleSidebar() {
                    document.getElementById('sidebar').classList.toggle('active');
                    document.querySelector('.sidebar-overlay').classList.toggle('active');
                }
            </script>