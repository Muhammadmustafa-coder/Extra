<?php include __DIR__ . '/header.php'; ?>

<div class="header-bar">
    <h2>Dashboard</h2>
    <div class="user-info">Welcome, Admin</div>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <span class="stat-label">Total Miqaats</span>
        <span class="stat-value">
            <?= $stats['miqaats'] ?>
        </span>
    </div>
    <div class="stat-card">
        <span class="stat-label">Total Users</span>
        <span class="stat-value">
            <?= $stats['users'] ?>
        </span>
    </div>
    <div class="stat-card">
        <span class="stat-label">Total Attendance</span>
        <span class="stat-value">
            <?= $stats['attendance'] ?>
        </span>
    </div>
</div>

<div class="card">
    <h3 class="card-title">Recent Attendance</h3>
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>User</th>
                    <th>Miqaat</th>
                    <th>Time</th>
                    <th>IP</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recent as $r): ?>
                    <tr>
                        <td>
                            <?= htmlspecialchars($r['username']) ?>
                        </td>
                        <td>
                            <?= htmlspecialchars($r['miqaat_title']) ?>
                        </td>
                        <td>
                            <?= $r['created_at'] ?>
                        </td>
                        <td>
                            <?= $r['ip_address'] ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($recent)): ?>
                    <tr>
                        <td colspan="4" class="text-muted">No recent data</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include __DIR__ . '/footer.php'; ?>