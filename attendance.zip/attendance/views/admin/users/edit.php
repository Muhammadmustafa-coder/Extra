<?php include __DIR__ . '/../header.php'; ?>

<div class="header-bar">
    <h2>Edit User:
        <?= htmlspecialchars($user['username']) ?>
    </h2>
    <a href="<?= htmlspecialchars(url('/admin/users')) ?>" class="btn btn-secondary">Back</a>
</div>

<div class="center-card">
    <div class="card">
        <form action="<?= htmlspecialchars(url('/admin/users/edit/' . $user['id'])) ?>" method="post">
            <div class="form-group">
                <label class="form-label">Full Name</label>
                <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($user['name'] ?? '') ?>"
                    placeholder="Member's Full Name" required>
            </div>
            <div class="form-group">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control"
                    value="<?= htmlspecialchars($user['email'] ?? '') ?>" placeholder="Email Address">
            </div>
            <div class="form-group">
                <label class="form-label">Role</label>
                <select name="role" class="form-control">
                    <option value="member" <?= $user['role'] === 'member' ? 'selected' : '' ?>>Member</option>
                    <option value="admin" <?= $user['role'] === 'admin' ? 'selected' : '' ?>>Admin</option>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">New Password (leave blank to keep current)</label>
                <input type="password" name="password" class="form-control" placeholder="New Password">
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%">Update User</button>
        </form>
    </div>
</div>

<?php include __DIR__ . '/../footer.php'; ?>