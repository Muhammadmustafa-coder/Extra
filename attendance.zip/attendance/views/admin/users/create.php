<?php include __DIR__ . '/../header.php'; ?>

<div class="header-bar">
    <h2>Create User</h2>
    <a href="<?= htmlspecialchars(url('/admin/users')) ?>" class="btn btn-secondary">Back</a>
</div>

<div class="center-card">
    <div class="card">
        <?php if (isset($error)): ?>
            <div class="alert alert-error">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <form action="<?= htmlspecialchars(url('/admin/users/create')) ?>" method="post">
            <div class="form-group">
                <label class="form-label">ITS Number (User ID)</label>
                <input type="text" name="username" class="form-control" placeholder="8-digit ITS Number" pattern="\d{8}"
                    title="Must be exactly 8 digits" required>
            </div>
            <div class="form-group">
                <label class="form-label">Full Name</label>
                <input type="text" name="name" class="form-control" placeholder="Member's Full Name" required>
            </div>
            <div class="form-group">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" placeholder="Email Address (for notifications)"
                    required>
            </div>
            <div class="form-group">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <div class="form-group">
                <label class="form-label">Role</label>
                <select name="role" class="form-control">
                    <option value="member">Member</option>
                    <option value="admin">Admin</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%">Create User</button>
        </form>
    </div>
</div>

<?php include __DIR__ . '/../footer.php'; ?>