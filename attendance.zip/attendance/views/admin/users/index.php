<?php include __DIR__ . '/../header.php'; ?>

<div class="header-bar">
    <h2>Users</h2>
    <a href="<?= htmlspecialchars(url('/admin/users/create')) ?>" class="btn btn-primary">Add New User</a>
</div>

<div class="card">
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>ITS (User ID)</th>
                    <th>Name</th>
                    <th>Role</th>
                    <th>Created At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $u): ?>
                    <tr>
                        <td style="font-family:monospace; font-weight:600;">
                            <?= htmlspecialchars($u['username']) ?>
                        </td>
                        <td>
                            <?= htmlspecialchars($u['name'] ?? '-') ?>
                        </td>
                        <td>
                            <span class="badge badge-<?= $u['role'] ?>">
                                <?= $u['role'] ?>
                            </span>
                        </td>
                        <td>
                            <?= $u['created_at'] ?>
                        </td>
                        <td>
                            <div class="actions">
                                <a href="<?= htmlspecialchars(url('/admin/users/edit/' . $u['id'])) ?>"
                                    class="btn btn-sm btn-secondary">Edit</a>
                                <?php if ($u['username'] !== 'admin'): ?>
                                    <a href="<?= htmlspecialchars(url('/admin/users/delete/' . $u['id'])) ?>"
                                        class="btn btn-sm btn-danger" onclick="return confirm('Delete user?');">Delete</a>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include __DIR__ . '/../footer.php'; ?>